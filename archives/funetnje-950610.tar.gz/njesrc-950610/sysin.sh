#!/bin/sh

#
#  Pseudo-program for receiving SYSIN jobs from NJE network
#

exit 0
# Yeah, do nothing..
