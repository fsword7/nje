#!/bin/sh -x
PATH=/usr/local/bin:/etc:/usr/etc:/bin:/usr/ucb:/usr/bin:
export PATH
agelog XMAILER.NAMES		12 OLD
agelog CADOMAIN.NAMES		12 OLD
#agelog routes.bitnet		12 OLD
